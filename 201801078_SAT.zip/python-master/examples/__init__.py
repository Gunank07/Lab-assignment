from pubnub.pnconfiguration import PNConfiguration

pnconf = PNConfiguration()

pnconf.subscribe_key = "demo"
pnconf.publish_key = "demo"
pnconf.enable_subscribe = False
